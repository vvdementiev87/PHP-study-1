<?php

$name = readline("Укажите Ваше имя: ");
$age = readline("Укажите Ваш возвраст: ");

echo "Вас зовут {$name}, вам {$age} лет";

?>